Check .java first, then delete folder with it.

Then check directory of .py, save results and proceed.