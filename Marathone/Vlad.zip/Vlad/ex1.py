import hedgehog as hh
import pandas as pd

db = hh.BayesNet(
    ('Burglary', 'Alarm'),
    ('Earthquake', 'Alarm'),
    ('Alarm', 'Vlad writes'),
    ('Alarm', 'Anna writes'))

print(db)

# P(Burglary)
db.P['Burglary'] = pd.Series({False: .999, True: .001})

# P(Earthquake)
db.P['Earthquake'] = pd.Series({False: .998, True: .002})

# P(Alarm | Burglary, Earthquake)
db.P['Alarm'] = pd.Series({
 (True, True, True): .95,
 (True, True, False): .05,

 (True, False, True): .94,
 (True, False, False): .06,

 (False, True, True): .29,
 (False, True, False): .71,

 (False, False, True): .001,
 (False, False, False): .999
})

# P(Vlad writes | Alarm)
db.P['Vlad writes'] = pd.Series({
 (True, True): .9,
 (True, False): .1,
 (False, True): .05,
 (False, False): .95
})

# P(Anna writes | Alarm)
db.P['Anna writes'] = pd.Series({
 (True, True): .7,
 (True, False): .3,
 (False, True): .01,
 (False, False): .99
})
db.prepare()

a = db.query('Burglary', event={'Anna writes': True, 'Vlad writes': True})
print(a)

a = db.query('Vlad writes', 'Anna writes', event={'Earthquake': True})
print(a)