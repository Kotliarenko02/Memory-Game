from python_loc_counter import LOCCounter
import pprint

def loc():
    """calculate LOCCounter"""
    counter = LOCCounter("ex1.py")
    loc_db = counter.getLOC()
    print("LOC", loc_db)
    pprint.pprint(loc_db)
    for k in loc_db:
        print(f"{k}: {loc_db[k]}")

if __name__ == "__main__":
    loc()
